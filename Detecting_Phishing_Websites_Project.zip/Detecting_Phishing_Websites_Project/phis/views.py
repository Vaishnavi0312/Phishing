from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def index(request):
    add=request.POST.get("add")
    print(add)
    f=open("address.txt",'w+')
    f.write(add)
    return HttpResponse("URL Copied")
# Create your views here.
