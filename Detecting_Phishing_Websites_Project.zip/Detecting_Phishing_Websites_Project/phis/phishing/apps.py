from django.apps import AppConfig


class PhisConfig(AppConfig):
    name = 'phishing'
