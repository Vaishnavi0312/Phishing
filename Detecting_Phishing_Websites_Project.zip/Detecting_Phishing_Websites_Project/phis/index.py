# -*- coding: utf-8 -*-

#importing libraries
#Scikit-learn is a free software machine learning library.
from sklearn.externals import joblib#Joblib is a set of tools to provide lightweight pipelining in Python.
                                    #is a set of data processing elements connected in series,
                                    #where the output of one element is the input of the next one.
                                    #is a set of data processing elements connected in series,
                                    #where the output of one element is the input of the next one.

import inputScript#to perform I/O task in Python.

#load the pickle file
classifier = joblib.load('final_models/rf_final.pkl')#Python pickle module is used for serializing and de-serializing a Python object structure. ...
# Pickling is a way to convert a python object (list, dict, etc.) into a character stream.
# The idea is that this character stream contains all the information necessary to reconstruct the object in another python script.

#input url
print("URL Copied")
#url = input()
url=''
f=open('../address.txt','r+')
url=f.readline()
print(url)


#checking and predicting
checkprediction = inputScript.main(url)
prediction = classifier.predict(checkprediction)
print("Prediction Result:",prediction)

if (prediction[0]) == 1:
    print("The website has phishing features. DO NOT VISIT!")
    print("PHISHING")
elif (prediction[0]) == -1:
    print("The website is safe to browse")
    print("SAFE")

import smtplib

if (prediction[0] == -1):
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.ehlo()
    server.starttls()
    server.login("sreekanthunnam@gmail.com", "123@Sree")
    server.sendmail("sreekanthunnamgmail.com", "kvaishnavitina26@gmail.com",
                    "Subject:Welcome....\n\n We found that website is safe to browse.")
    server.close()
    print("successfully sent the mail")
elif (prediction[0]==1):
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.ehlo()
    server.starttls()

    server.login("sreekanthunnam@gmail.com", "123@Sree")
    server.sendmail("sreekanthunnam@gmail.com", "kvaishnavitina26@gmail.com",
                    "Subject:Alert!!!!!\n\n We found that website has pishing features.")
    server.close()

    print("Successfully sent the alert mail")


