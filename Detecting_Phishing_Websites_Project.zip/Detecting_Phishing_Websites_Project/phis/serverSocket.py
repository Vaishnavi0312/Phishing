import socket
serv=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
serv.bind(('192.168.1.98',65432))
serv.listen(5)
while True:
    conn,addr=serv.accept()
    while True:
        url=conn.recv(4096)
        print(url)
        conn.send(b"Received")
    conn.close()